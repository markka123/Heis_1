#include <stdint.h>
#include "ppi.h"
#include "gpio.h"
#include "gpiote.h"





void led_on() {
	unsigned int bitmask = (1 << 17);
	GPIO->OUT = GPIO->OUT | bitmask;
};

void led_off() {
	unsigned int bitmask = (0 << 17);
	bitmask = ~bitmask;
	GPIO->OUT = GPIO->OUT && bitmask;
}



int main(){
	// Configure LED Matrix, til av
	

    GPIO->OUT = 0 << 17 | 0 << 18 | 0 << 19 | 0 << 20; 
    //Kanal lytte til button1

    GPIOTE->CONFIG[0] = 1 | 1 << 17 | 1 << 11 | 1 << 10 | 1 << 8; //Event mode, 11 10 og 8 for å lytte på GPIO 13 (knapp 1)
    
    
    GPIOTE->CONFIG[1] = 3 | 1 << 16 | 1 << 17 | 1 << 12 | 1 << 8; //Task mode, toogle og satt til hvert sitt lys GPIO 17 - 20
    GPIOTE->CONFIG[2] = 3 | 1 << 16 | 1 << 17 | 1 << 12 | 1 << 9;
    GPIOTE->CONFIG[3] = 3 | 1 << 16 | 1 << 17 | 1 << 12 | 1 << 9 | 1 << 8;
    GPIOTE->CONFIG[4] = 3 | 1 << 16 | 1 << 17 | 1 << 12 | 1 << 10;

    //Setter PPI-registrene og kobler eventet mot hver sin task
    PPI->PPI_CH[0].EEP = (uint32_t)&(GPIOTE->IN[0]); //EEP = EventEndPoint
    PPI->PPI_CH[0].TEP = (uint32_t)&(GPIOTE->OUT[1]); //TEP = TaskEndPoint
    PPI->CHENSET = 1 << 0;
    
    PPI->PPI_CH[1].EEP = (uint32_t)&(GPIOTE->IN[0]); //EEP = EventEndPoint
    PPI->PPI_CH[1].TEP = (uint32_t)&(GPIOTE->OUT[2]); //TEP = TaskEndPoint
    PPI->CHENSET = 1 << 1;
    
    PPI->PPI_CH[2].EEP = (uint32_t)&(GPIOTE->IN[0]); //EEP = EventEndPoint
    PPI->PPI_CH[2].TEP = (uint32_t)&(GPIOTE->OUT[3]); //TEP = TaskEndPoint
    PPI->CHENSET = 1 << 2;

    PPI->PPI_CH[3].EEP = (uint32_t)&(GPIOTE->IN[0]); //EEP = EventEndPoint
    PPI->PPI_CH[3].TEP = (uint32_t)&(GPIOTE->OUT[4]); //TEP = TaskEndPoint
    PPI->CHENSET = 1 << 3;

	int sleep = 0;
	
	while(1){
		
		
		sleep = 10000;
		while(--sleep); // Delay
	}
	return 0;
}
