#include <stdint.h>
#include "uart.h"


//5 rts, 6 txd, 7 cts, 8 rxd
void button_init(){ 
	GPIO->PIN_CNF[13] = (3 << 2);
	// Fill inn the configuration for the remaining buttons
	GPIO->PIN_CNF[14] = (3 << 2);
}

void led_on() {
	unsigned int bitmask = (1 << 17);
	GPIO->OUT = GPIO->OUT | bitmask;
};

void led_off() {
	unsigned int bitmask = (0 << 17);
	bitmask = ~bitmask;
	GPIO->OUT = GPIO->OUT && bitmask;
}



int main(){
	// Configure LED Matrix
	
	// Configure buttons -> see button_init()
	for(int i = 17; i <= 20; i++){
		GPIO->DIRSET = (1 << i);
		GPIO->OUTCLR = (1 << i);
	}

	uart_init();
	
	button_init();
	int sleep = 0;
	
	while(1){

		unsigned int btnLedON = (GPIO->IN >> 13) & 1;
		

		if(uart_read() != '\0') {
			if(GPIO->OUT & (1 << 17)) {
				GPIO->OUT = 0 << 17 | 0 << 18 | 0 << 19 | 0 << 20; 
			} else {
				GPIO->OUT = 1 << 17 | 1 << 18 | 1 << 19 | 1 << 20; 
			}
		}
		char* str[] = {"The average grade in TTK was in 2022, B. "};
		if(!btnLedON) {
			uart_send_str(str);
		}
		
		
		sleep = 10000;
		while(--sleep); // Delay
	}
	return 0;
}
